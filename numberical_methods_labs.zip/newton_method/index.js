const makeStep = (curve, curveP, x) => x - (curve(x) / curveP(x));

module.exports.getRoot = function getRoot(curve, curveP, startValue, errorRange, config) {
	const writeOutput = config?.output?.source;

	let currentValue = startValue;
	let iterationCount = 0;

	while (Math.abs(curve(currentValue)) > errorRange) {
		if (writeOutput) writeOutput(`curValue = ${currentValue}; iteration = ${iterationCount}`);
		iterationCount++;
		currentValue = makeStep(curve, curveP, currentValue);
	}

	return currentValue;
};
