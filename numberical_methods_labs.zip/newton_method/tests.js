const { getRoot } = require('./index.js');

const consoleOutputConfig = {
	output: {
		source: console.log
	}
};


const curve1 = (x) => 1 - 1 / x;
const curveP1 = (x) => 1 / (x * x);

const root1 = getRoot(curve1, curveP1, 1/4, 1e-3, consoleOutputConfig);

console.log(root1, curve1(root1));
