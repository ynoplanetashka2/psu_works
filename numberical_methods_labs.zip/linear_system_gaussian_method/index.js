/* function submatrix(matrix, rowStart, rowEnd, columnStart, columnEnd) {
	return matrix
		.map(row => row
			.filter((_, ind) => columnStart <= ind || ind < columnEnd))
		.filter((_, ind) => rowStart <= ind || ind < rowEnd);
}; */

function submatrix(matrix, row, column) {
	return matrix
		.map(row => row
			.filter((_, ind) => ind !== column))
		.filter((_, ind) => ind !== row);
};

function det(matrix) {
	const size = matrix.length;

	if (size === 1) {
		return matrix[0][0];
	}
	
	var sign = 1;
	var result = 0;

	for (var i = 0; i < size; i++) {
		result += sign * det(submatrix(matrix, 0, i)) * matrix[0][i];
		sign *= -1;
	}

	return result;
}

module.exports.det = det;


module.exports.solveLinearSystem = function solveLinearSystem(matrix /* extended matrix of a system */) {

	const rowsCount = matrix.length;
	const columnsCount = rowsCount + 1;

	var currentItem;

	for (var currentRow = 0, currentColumn = 0; currentRow < rowsCount; currentRow++, currentColumn++) {
		var nonZeroTermFinded = false;

		for (var i = currentRow; i < rowsCount; i++) {
			if (matrix[i][currentColumn] !== 0) {
				nonZeroTermFinded = true;
				[matrix[i], matrix[currentRow]] = [matrix[currentRow], matrix[i]];
				break;
			}
		}

		if (!nonZeroTermFinded) {
			throw new Error('invalid input matrix. cant find non-zero term', matrix);
		}

		for (var i = currentRow + 1; i < rowsCount; i++) {
			const nullishCoefficient = (-1) * matrix[i][currentColumn] / matrix[currentRow][currentColumn];

			matrix[i][currentColumn] = 0;

			for (var j = currentColumn + 1; j < columnsCount; j++) {
				matrix[i][j] += nullishCoefficient * matrix[currentRow][j];
			}
		}
	}

	var result = [];

	for (var i = rowsCount - 1; i >= 0; i--) {

		var sum = matrix[i][columnsCount - 1];

		for (var j = columnsCount - 2, counter = 0; j > i; j--, counter++) {

			sum -= matrix[i][j] * result[counter];
		}

		result.push( sum / matrix[i][i] );
	}

	return result.reverse();
};

