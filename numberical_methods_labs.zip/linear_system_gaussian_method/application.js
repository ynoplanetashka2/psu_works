const { solveLinearSystem, det } = require('./index.js');

const matrix = [
	[3.4, 2, 8, 3],
	[2, -4.5, 5, 7],
	[1, 4.3, -2, 2]
];

const operator = matrix
	.map(row => row.slice(0, row.length - 1));

const solution = solveLinearSystem(matrix);

console.log(solution);
console.log(3.4 * solution[0] + 2 * solution[1] + 8 * solution[2] - 3);
console.log(det(operator));
