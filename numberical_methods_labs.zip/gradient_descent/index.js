function sumVectors(...vectors) {
	if (vectors.length === 0)
		throw new Error('0 arguments passed');

	const _length = vectors[0].length;

	var result = new Array(_length).fill(0);

	vectors.forEach(vector =>
		vector.forEach((coordinate, index) =>
			result[index] += coordinate
		)
	);

	return result;
}

function scaleVector(vector, scaleFactor) {
	return vector.map(item => item * scaleFactor);
}

function inverseVector(vector) {
	return scaleVector(vector, -1);
}

function getLength(vector) {
	return Math.sqrt(vector.reduce((acc, coordinate) => acc + coordinate * coordinate, 0));
}

function getArgMinGD(
	curve,
	curveP, // array of partial derivitives 
	stepScale = 1e-2,
	preciseness = 1e-2,
	startPoint = new Array(curve.length).fill(0),
	maxStepCount = 1e3
) {
	var currentValue = startPoint;

	const iterStep = (currentValue) => curveP.map((func) => func(...currentValue));

	var delta = iterStep(currentValue);

	var stepCount = 0;
	while (getLength(delta) >= preciseness) {
		if (stepCount >= maxStepCount) {
			throw new Error(`maxStepCount achived ${stepCount}`);
		}
		
		delta = scaleVector(delta, -stepScale);

		currentValue = sumVectors(currentValue, delta);
		 console.log(currentValue, delta);

		delta = iterStep(currentValue);
		stepCount++;
	}

	currentValue = sumVectors(currentValue, delta);

	return currentValue;
}


module.exports = {
	...module.exports,
	getArgMinGD
};
