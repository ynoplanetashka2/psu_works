const { getArgMinGD } = require('./index.js');

const curve = (x, y) => x**3 + 2 * y**2 - 3 * x- 4 * y;
const curveP = [
	(x, y) => ( 3 * x**2 - 3 ),
	(x, y) => ( 4 * y - 4)
];

const startPoint = [-0.5, -1];

const result = getArgMinGD(curve, curveP, undefined, 1e-6, startPoint, 1e6);

console.log(result, curveP[0](...result), curveP[1](...result));
