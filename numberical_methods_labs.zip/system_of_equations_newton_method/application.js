const { getRootOfSystem } = require('./index.js');

const curve1 = (x, y) => Math.tan(x * y + 0.1) - x * x;
const curve1XPrime = (x, y) => (1 + ((Math.tan(x * y + 0.1)) ** 2)) * y - 2 * x;
const curve1YPrime = (x, y) => (1 + ((Math.tan(x * y + 0.1)) ** 2)) * x;

const curve2 = (x, y) => .7 * x * x + 2 * y * y - 1;
const curve2XPrime = (x, y) => .7 * 2 * x;
const curve2YPrime = (x, y) => 2 * 2 * y;

const root = getRootOfSystem(
		curve1,
		curve1XPrime,
		curve1YPrime,
		curve2,
		curve2XPrime,
		curve2YPrime,
		1,
		0,
		1e-6
	);

console.log(root);
console.log(curve1(root.x, root.y), curve2(root.x, root.y));
