module.exports.getRootOfSystem = function getRootOfSystem(
		curve1,
		curve1XPrime,
		curve1YPrime,
		curve2,
		curve2XPrime,
		curve2YPrime,
		xStart,
		yStart,
		preciseness
	) {

	var x, y;
	x = xStart;
	y = yStart;

	var xDif, yDif;

	const xDifIter = () => - (curve1(x, y) * curve2YPrime(x, y) - curve1YPrime(x, y) * curve2(x, y)) / (curve1XPrime(x, y) * curve2YPrime(x, y) - curve1YPrime(x, y) * curve2XPrime(x, y));


	const yDifIter = () => - (curve1XPrime(x, y) * curve2(x, y) - curve1(x, y) * curve2XPrime(x, y)) / (curve1XPrime(x, y) * curve2YPrime(x, y) - curve1YPrime(x, y) * curve2XPrime(x, y));

	xDif = xDifIter();
	yDif = yDifIter();


	while (Math.max( Math.abs(xDif), Math.abs(yDif) ) >= preciseness) {

		x += xDif;
		y += yDif;

		xDif = xDifIter();
		yDif = yDifIter();

		console.log(x, y, xDif, yDif);
	}

	return {x, y};
};
