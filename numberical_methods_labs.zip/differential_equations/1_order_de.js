function solveDERK(curveP, initialCondition, intervalLength, preciseness = 1e-3, xCoef, yCoef, wCoef) {
	const [xStart, yStart] = initialCondition;
	const order = wCoef.length;

	xCoef = [0].concat(xCoef);
	yCoef = [[]].concat(yCoef);

	return (x) => {
		var stepLength = x >= xStart ? intervalLength : -intervalLength;
		const predicate = (xCur, x) => Boolean(x >= xStart ? xCur < x - stepLength : xCur > x - stepLength);

		var xCur = xStart, yCur = yStart;
		var yPrev;

		const iterStep = () => {
			const curveValues = new Array(order);

			for (var i = 0; i < order; i++) {
				curveValues[i] = curveP(
					xCur + stepLength * xCoef[i],
					yCur + stepLength * yCoef[i].reduce((sum, coef, ind) => sum + ( ind < i ? ( coef * curveValues[ind] ) : 0 ), 0)
				);
			}
			const delta = stepLength * wCoef.reduce((sum, weight, index) => sum + weight * curveValues[index], 0);

			return delta;
		}

		const refineValue = () => {
			var delta, yCurTemp;

			const yNext = () => {
				return yPrev + stepLength * (curveP(xCur, yPrev) + curveP(xCur + stepLength, yCur)) / 2;
			};

			do {
				yCurTemp = yCur;
				yCur = yNext();
				delta = yCur - yCurTemp;

			} while (Math.abs(delta) >= preciseness) 

			return yCur;
		}


		for (
			;
			predicate(xCur, x);
			xCur += stepLength
		) {
			yPrev = yCur;
			yCur += iterStep();

			// yCur = refineValue();
		}

		stepLength = x - xCur;
		yCur += iterStep();

		// yCur = refineValue();

		return yCur;
	}
}

const solveDEN = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, 1e-3, [], [[]], [1]);
const solveDENF = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, 1e-3, [.5], [[.5]], [.5, .5]);
const solveDENM = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, 1e-3, [.5], [[.5]], [0, 1]);

const solveDERKC1 = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, 1e-3, [.5, .5, 1], [[.5], [0, .5], [0, 0, 1]], [1, 2, 2, 1].map(i => i / 6));
const solveDERKC2 = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, 1e-3, [.25, .5, 1], [[.25], [0, .5], [1, -2, 2]], [1, 0, 4, 1].map(i => i / 6));

module.exports = {
	solveDERK,
	solveDEN,
	solveDENF,
	solveDENM,
	solveDERKC1,
	solveDERKC2,
};
