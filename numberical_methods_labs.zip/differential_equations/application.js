/*
var { solveDEN, solveDENF, solveDENM, solveDERKC1, solveDERKC2 } = require('./1_order_de.js');

const curveP = (x, y) => x + Math.sin(y / Math.sqrt(.7));
const initialCondition = [1.2, 1.4];

const step = .1;
const domain = new Array(11).fill(initialCondition[0]).map((item, index) => item + step * index);

const curves = [solveDEN, solveDENF, solveDENM, solveDERKC1, solveDERKC2].map(metaCurve => metaCurve(curveP, initialCondition, 1e-3));
const curveLabels = 'newton method, newton method fixed, newton method modified, Runge-Kutta cubic method #1, Runge-Kutta cubic method #2'.split(', ');

const values = curves.map(curve => domain.map(curve));

var result = new Object;
var _temp;
curveLabels.forEach((label, index) => {
	_temp = new Object;
	domain.forEach((arg, ind) => {
		_temp[`x = ${arg}`] = values[index][ind];
	});
	result[label] = _temp;
});

console.table(result);
*/


/*
var { solveDERKC, solveDEN } = require('./solve_de.js');

const curveP = (x, yP0, yP1) => Math.cos(yP0) / (1.25 + x) - .5 * yP1;
const initialCondition = [0, [0, 1]];

const step = .1;
const domain = new Array(6).fill(0).map((item, index) => item + step * index);

const curves = [solveDERKC, solveDEN].map(metaCurve => metaCurve(curveP, initialCondition, 1e-3));
const curveLabels = 'Runge-Kutta cubic method, Newton\'s method'.split(', ');

const values = curves.map(curve => domain.map(curve));

var result = new Object;
var _temp;
curveLabels.forEach((label, index) => {
	_temp = new Object;
	domain.forEach((arg, ind) => {
		_temp[`x = ${arg}`] = values[index][ind];
	});
	result[label] = _temp;
});

console.table(result);
*/


var { solveBVP } = require('./solve_bvp.js');

const curve = (x, yP0, yP1) => yP0 - yP1 / x;
const conditions = [
	{
		point: 1,
		condition: (x, yP0, yP1) => yP0 - 3
	},
	{
		point: 5,
		condition: (x, yP0, yP1) => yP0 - 5
	}
];

const func = solveBVP(curve, conditions, {
	initialConditionRungeKuttaPoint: 1,
});

const step = .1;
const domain = new Array(51).fill(0).map((item, index) => item + step * index);

const values = domain.map(func);

var result = new Object;
var _temp;

_temp = new Object;
domain.forEach((arg, ind) => {
	_temp[`x = ${arg}`] = values[ind];
})
result['BVP solution'] = _temp;

//console.table(result);

var queryObject = {
  type: 'line',
  data: {
    labels: domain.map(val => Math.round(10*val)/10).slice(6),
    datasets: [{
      label: 'curve',
      data: values.map(([fst, snd]) => snd).slice(6),
      fill: false,
      borderColor: 'green',
      backgroundColor: 'green',
    }]
  }
};

const query = JSON.stringify(queryObject);
// console.log(query);
