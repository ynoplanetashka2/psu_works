
/* function solveDERK(curveP, initialCondition, intervalLength, preciseness = 1e-3, xCoef, yCoef, wCoef) {
	const [xStart, yStart] = initialCondition;
	const DEOrder = yStart.length;
	const RKOrder = wCoef.length;

	xCoef = [0].concat(xCoef);
	yCoef = [[]].concat(yCoef);

	return (x) => {
		var stepLength = x >= xStart ? intervalLength : -intervalLength;
		const predicate = (xCur, x) => Boolean(x >= xStart ? xCur < x - stepLength : xCur > x - stepLength);

		var iterCount = 0;
		var xCur = xStart;
		var result = yStart.map(i => i);

		const iterStep = () => {

			const curveValues = new Array(DEOrder).fill(undefined).map(_ => new Array(RKOrder));

			for (var i = 0; i < RKOrder; i++) {

				const args = result
					.map((item, index) => item + yCoef[i] 
						.reduce((sum, coef, ind) => sum + coef * curveValues
							.reduce((acc, item, _ind) => ( _ind === ind ? item[ind] : 0 ), 0), 0));


				if (iterCount < 5) console.log(args, iterCount);
				curveValues.last[i] = stepLength * curveP(
					xCur + stepLength * xCoef[i],
					...args
				);
				
				for (var j = result.length - 2; j >= 0; j--) {
					curveValues[j][i] = stepLength * yCoef[i]
						.reduce((sum, coef, index) => sum + coef * curveValues
							.reduce((acc, item, ind) => ( index === ind ? item[ind] : 0 ), 0), 0);
				}
			}

			for (var i = 0; i < DEOrder; i++) {
				result[i] += wCoef.reduce((sum, coef, index) => sum + coef * curveValues[i][index], 0);
			}

			//if (iterCount < 5) console.log(curveValues, iterCount);
			iterCount++;
			return result;
		}


		for (
			;
			predicate(xCur, x);
			xCur += stepLength
		) {
			result = iterStep();
		}

		stepLength = x - xCur;
		result = iterStep();

		return result;
	}
}

function solveDERK(curveP, initialCondition, intervalLength, xCoef, yCoef, wCoef) {
	const [xStart, yStart] = initialCondition;
	const DEOrder = yStart.length;
	const RKOrder = wCoef.length;

	xCoef = [0].concat(xCoef);
	yCoef = [[]].concat(yCoef);

	return (x) => {
		var stepLength = xStart <= x ? intervalLength : -intervalLength;
		var xCur = xStart;
		var yCur = yStart;

		const predicate = () => xCur <= x ? xCur + stepLength < x : xCur + stepLength > x;

		const iterStep = () => {

			yApproximateValues = new Array(DEOrder).fill(undefined).map(_ => new Array(RKOrder));

			for (var i = 0; i < RKOrder; i++) {
				const args = yApproximateValues.map((item, index) => yCoef[i].reduce((sum, coef, ind) => sum + coef * item[ind], 0));
				console.log(args, i, yCur, xCur);
				yApproximateValues.last[i] = curveP(
					xCur + stepLength * xCoef[i],
					...args.map((item, index) => yCur[index] + stepLength * item)
				);
				console.log(yApproximateValues.last[i]);

				for (var j = DEOrder - 2; j >= 0; j--) {
					yApproximateValues[j][i] = yCur[j] + stepLength * yCoef[i].reduce((sum, coef, index) => sum + coef * yApproximateValues[j + 1][index], 0);
				}
			}

			for (var i = 0; i < DEOrder; i++) {
				yCur[i] += stepLength * wCoef.reduce((sum, coef, index) => sum + coef * yApproximateValues[i][index], 0);
			}

			return yCur;
		}

		for (
			;
			predicate();
			xCur += stepLength
		) {
			iterStep();
		}

		stepLength = x - xCur;
		iterStep();

		return yCur.slice(0, -1);
	};
}*/

Object.defineProperty(Array.prototype, 'last', { get() { return this[this.length - 1]; }, set(value) { return this[this.length - 1] = value; } } );



function solveDERK(curveP, initialCondition, intervalLength, xCoef, yCoef, wCoef) {

	xCoef = [0].concat(xCoef);
	yCoef = [[]].concat(yCoef);

	var [xStart, yStart] = initialCondition;
	const DEOrder = yStart.length;
	const RKOrder = xCoef.length;

	return (x) => {

		var stepLength = xStart <= x ? intervalLength : -intervalLength;
		var xCur = xStart;
		var yCur = yStart.map(i => i);

		const predicate = () => xCur <= x ? xCur + stepLength < x : xCur + stepLength > x;

		const iterStep = () => {
			const approximateValues = new Array(DEOrder).fill(undefined).map(_ => new Array(RKOrder));

			for (var j = 0; j < RKOrder; j++) {
				const args = yCur
					.map((item, index) => item + stepLength * yCoef[j].reduce((sum, coef, ind) => sum + coef * approximateValues[index][ind], 0));
				approximateValues.last[j] = curveP(xCur + stepLength * xCoef[j], ...args);

				for (var i = DEOrder - 2; i >= 0; i--) {
					approximateValues[i][j] = yCur[i + 1] + stepLength * yCoef[j].reduce((sum, coef, ind) => sum + coef * approximateValues[i][ind], 0);
				}
			}

			for (var i = 0; i < DEOrder; i++) {
				yCur[i] += stepLength * wCoef.reduce((sum, coef, index) => sum + coef * approximateValues[i][index], 0);
			}

			return yCur;
		}

		for (
			;
			predicate();
			xCur += stepLength
		) {
			yCur = iterStep();
		}

		return yCur;
	}
}

		
const solveDEN = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, [], [], [1]);
const solveDERKC = (curveP, initialCondition, intervalLength) => solveDERK(curveP, initialCondition, intervalLength, [.5, .5, 1], [[.5], [0, .5], [0, 0, 1]], [1, 2, 2, 1].map(i => i/6));


module.exports = {
	solveDERK,
	solveDEN,
	solveDERKC,
};
