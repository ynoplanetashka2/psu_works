// boundary value problem

const { solveDERKC } = require('./solve_de.js');
const { getRoot } = require('../bisection_method/bisection_improved.js');

// condition is an object of signature {point: number, condition: (funcP0, funcP1, ...) => number}

function solveBVP(
	func,
	conditions,
	conf
) {
	const order = conditions.length;

	const _defaultConf = {
		intervalLengthRungeKutta: 1e-2,
		initialConditionRungeKuttaPoint: 0,
		initialConditionRungeKuttaValues: new Array(order).fill(0)
	}

	conf = Object.assign(_defaultConf, conf);
	const { intervalLengthRungeKutta, initialConditionRungeKuttaPoint, initialConditionRungeKuttaValues } = conf;


	const dep = (...iniCond) => {
		const curves = solveDERKC(func, [initialConditionRungeKuttaPoint, iniCond], intervalLengthRungeKutta);
		const result = conditions.map((condition, index) => condition.condition(condition.point, ...curves(condition.point)));

		return result;
	}
	Object.defineProperty(dep, 'length', { value: order, configurable: true });

	const initialCondition = getRoot(dep, {arity: order, intervalLength: 1, preciseness: 1e-2, startPoint: initialConditionRungeKuttaValues});

	return solveDERKC(func, [initialConditionRungeKuttaPoint, initialCondition], intervalLengthRungeKutta);
}

module.exports = {
	solveBVP
}
