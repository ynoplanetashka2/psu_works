const { getLagrangePolynomial } = require('./lagrange_polynomial.js');
const { getNewtonPolynomial, getNewtonPolynomialR } = require('./newton_polynomial.js');

const pointsA = [
	.38,
	.65,
	.92,
	1.19,
	1.46,
	1.73
]

const valuesA = [
	0.970672,
	3.01765,
	6.326288,
	11.01476,
	17.20114,
	25.00352
];

/*
const desiredPointA = 1;

const resA = getLagrangePolynomial(pointsA, valuesA);
const curveA = resA.curve;

console.log(resA);
console.log(curveA(desiredPointA));
const pointsB = [
	5.2,
	3.6,
	1.8,
	0.5,
	-1.6,
	-3.3
];

const valuesB = [
	100.568,
	29.933,
	2.052,
	-0.175,
	-8.736,
	-53.097
];

const desiredPointB = 3.5;

const resB = getLagrangePolynomial(pointsB, valuesB);
const curveB = resB.curve;

console.log(resB);
console.log(curveB(desiredPointB));

*/
// newton way


const desiredPointN1 = 0.39;
const desiredPointN2 = 1.74;

const resultN = getNewtonPolynomial(pointsA, valuesA);
const curveN = resultN.curve;

console.log(resultN);
console.log(curveN(desiredPointN1), curveN(desiredPointN2));

const resultNR = getNewtonPolynomialR(pointsA, valuesA);
const curveNR = resultNR.curve;

console.log(resultNR);
console.log(curveNR(desiredPointN1), curveNR(desiredPointN2));
