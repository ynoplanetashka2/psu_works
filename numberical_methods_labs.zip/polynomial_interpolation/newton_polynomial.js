Array.prototype.mapRight = function mapRight(func) {
	var result = new Array();

	for (var i = this.length - 1; i >= 0; i--) {
		result[i] = func(this[i], i, this);
	}

	return result;
}

function dividedDifference(points, values) {
	const length = points.length;

	if (length === 1) {
		return values[0];
	}

	const denominator = points[length - 1] - points[0];

	return (dividedDifference( points.slice(1), values.slice(1) ) - dividedDifference( points.slice(0, -1), values.slice(0, -1) )) / denominator;
}


function getNewtonPolynomial(points, values) {
	var dividedDifferences = new Array();

	const length = points.length;

	points.forEach((item, index) => dividedDifferences[index] = dividedDifference(points.slice(0, index + 1), values.slice(0, index + 1)));

	const curve = (x) => dividedDifferences
		.reduce((res, coefficient, index) => res + coefficient * points
			.reduce((acc, i, ind) => acc * ( ind < index ? ( x - i ) : 1 ), 1), 0);

	return {
		curve,
		coefficients: dividedDifferences
	};
}


function getNewtonPolynomialR(points, values) {
	return getNewtonPolynomial(points.reverse(), values.reverse());
}

module.exports = {
	...module.exports,
	getNewtonPolynomial,
	getNewtonPolynomialR
};
