function getLagrangePolynomial(points, values) {

	var denominators = points
		.map((item, index) => points
			.reduce((acc, i, ind) => acc * ( ind !== index ? (item - i) : 1), 1));

	var coefficients = denominators.map((item, index) => values[index] / item);

	var result = (x) => points
		.reduce((res, item, index) => res + coefficients[index] * points
			.reduce((acc, i, ind) => acc * ( ind !== index ? ( x - i ) : 1 ), 1), 0);

	return {
		curve: result,
		coefficients,
		denominators
	};
}

module.exports.getLagrangePolynomial = getLagrangePolynomial;
