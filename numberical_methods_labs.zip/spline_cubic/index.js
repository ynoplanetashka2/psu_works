const { solveLinearSystem } = require('../linear_system_gaussian_method/index.js');


function cubicSpline(points, values, tail_condition /* left subcurve condition */, head_condition) {
	var equations = new Array();

	function substituteEquation(coef, index, independentTerm) {
		equations.push( new Array(index).fill(0).concat( coef, new Array((points.length - 1) * 4 - index - coef.length).fill(0), [independentTerm] ) );
	}

	const iter = new Array(4).fill(undefined);

	const unknownVariablesCount = ( points.length - 1 ) * 4;
	const UVCC = unknownVariablesCount - 4; // unknownVariablesCountComplement

	equations.push( tail_condition.slice(0, -1).concat( new Array(UVCC).fill(0) , [tail_condition[4]] ) );
	equations.push( new Array(UVCC).fill(0).concat( head_condition ) );

	points.slice(0, -1).forEach((_, index) => {
		substituteEquation([1], index * 4, values[index]);

		const c1 = iter.map((_, ind) => (points[index + 1] - points[index]) ** (ind));

		substituteEquation(c1, index * 4, values[index + 1]);
	});
	
	points.slice(0, -2).forEach((_, index) => {

		var c1p0 = iter.map((_, ind) => (points[index + 1] - points[index]) ** (ind));
		var c1p1 = iter.map((_, ind) => ind * (points[index + 1] - points[index]) ** (ind - 1));
		var c1p2 = iter.map((_, ind) => ind * (ind - 1) * (points[index + 1] - points[index]) ** (ind - 2));

		var c2p0 = iter.map((_, ind) => (ind === 0 ? -1 : 0));
		var c2p1 = iter.map((_, ind) => (ind === 1 ? -1 : 0));
		var c2p2 = iter.map((_, ind) => (ind === 2 ? -2 : 0));

		// substitueEquation( c1p0.concat(c2p0), index * 4, 0);
		substituteEquation( c1p1.concat(c2p1), index * 4, 0);
		substituteEquation( c1p2.concat(c2p2), index * 4, 0);
	});

	const solution = solveLinearSystem(equations);

	return solution.filter((_, index) => index % 4 === 0).map((_, index) => solution.slice(4 * index, 4 * index + 4));
}

function piecewiseCurve(points, curves) {
	return (x) => curves[points.indexOf(points.find(point => x <= point)) - 1](x);
};

function polynom(coefficients, shift = 0) {
	return (x) => coefficients.reduce((acc, coef, ind) => acc + coef * ( (x - shift) ** ind ), 0);
}

module.exports = {
	...module.exports,
	cubicSpline,
	piecewiseCurve,
	polynom
};
