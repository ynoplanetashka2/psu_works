const { cubicSpline, piecewiseCurve, polynom } = require('./index.js');

const points = [
	13,
	14,
	18,
	20,
	25,
	27
];

const values = [
	-2,
	-5,
	4,
	10,
	5,
	1
];

const tail_condition = [0, 0, 1, 0, 0];
const head_condition = [0, 0, 1, 0, 0];

const desiredPoint = 22;

const result = cubicSpline(points, values, tail_condition, head_condition);
console.log(result);

const curve = piecewiseCurve(points, result.map((coeff, index) => polynom(coeff, points[index])));
console.log(curve(desiredPoint));

