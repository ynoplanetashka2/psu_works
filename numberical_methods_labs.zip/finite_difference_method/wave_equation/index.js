function* range(...args) {
	let from, to, step;
	switch (args.length) {
		case 1:
			from = 0;
			to = args[0];
			step = 1;
			break;
		case 2:
			from = args[0];
			to = args[1];
			step = 1;
			break;
		case 3:
			from = args[0];
			to = args[1];
			step = args[2];
			break;
	}

	for (let i = from; i < to; i += step) {
		yield i;
	}
}

const time = 5.5e3;
const position = 3.15;

const L = 10;
const A = 1e-3;
const n = 3;

const initialState = (x) => 0;
const initialVelocity = (x) => Math.sin(Math.PI * n * x / L);

const coordStep = 1e-2;
const timeStep = 1e-1;

function indexFromCoord(stepSize, coord) {
	return Math.ceil(coord / stepSize);
}

function coordFromIndex(stepSize, index) {
	return stepSize * index;
}

const elementsCount = indexFromCoord(coordStep, L) + 1;
let curState = [];
let pastState = [];
let futState = [];

pastState[0] = 0;
pastState[elementsCount - 1] = 0;
for (const i of range(1, elementsCount - 1)) {
	pastState[i] = initialState(coordFromIndex(coordStep, i));
}

curState[0] = 0;
curState[elementsCount - 1] = 0;
for (const i of range(1, elementsCount - 1)) {
	curState[i] = pastState[i] + timeStep * initialVelocity(coordFromIndex(coordStep, i));
}


for (const curTime of range(0, time, timeStep)) {
	futState[0] = 0;
	futState[elementsCount - 1] = 0;
	for (const i of range(1, elementsCount - 1)) {
		futState[i] = 2 * curState[i] - pastState[i] + A**2 * (timeStep**2 / coordStep**2) * (curState[i + 1] - 2 * curState[i] + curState[i - 1]);
	}
	
	[pastState, curState, futState] = [curState, futState, pastState];
}

let domain = futState.map((_, index) => coordFromIndex(coordStep, index));
let values = futState;


const pointsCount = 1e2;
const queryObject = {
  type: 'line',
  data: {
    labels: domain.map(val => Math.round(10*val)/10).filter((_, ind) => ind % Math.round(domain.length / pointsCount) === 0),
    datasets: [{
      label: 'curve',
      data: values.map(val => val).filter((_, ind) => ind % Math.round(domain.length / pointsCount) === 0),
      fill: false,
      borderColor: 'green',
      backgroundColor: 'green',
    }]
  }
};
const query = JSON.stringify(queryObject);
console.log(query);