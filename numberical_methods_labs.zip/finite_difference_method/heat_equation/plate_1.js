function* range(...args) {
	let from, to, step;
	switch (args.length) {
		case 1:
			from = 0;
			to = args[0];
			step = 1;
			break;
		case 2:
			from = args[0];
			to = args[1];
			step = 1;
			break;
		case 3:
			from = args[0];
			to = args[1];
			step = args[2];
			break;
	}

	for (let i = from; i < to; i += step) {
		yield i;
	}
}

// returns top left and right bottom points(ordered)
function mainDiagonalPoints(x1, y1, x2, y2) {
	if (x1 < x2) {
		if (y1 < y2) {
			return [
				[x1, y2],
				[x2, y1]
			];
		}
		return [
			[x1, y1],
			[x2, y2]
		];
	}
	if (y1 < y2) {
		return [
			[x2, y2],
			[x1, y1]
		];
	}
	return [
		[x2, y1],
		[x1, y2]
	];
}

function* flatRange(x1, y1, x2, y2, step = 1) {
	[[x1, y1], [x2, y2]] = mainDiagonalPoints(x1, y1, x2, y2);
	let curPos = [x1, y1];
	for (let i = x1; i <= x2; i += step) {
		for (let j = y1; j >= y2; j -= step) {
			yield [i, j];
		}
	}
}

function* circuitRange(x1, y1, x2, y2, step = 1) {
	[[x1, y1], [x2, y2]] = mainDiagonalPoints(x1, y1, x2, y2);
	let curPos = [x1, y1];

	while (curPos[1] > y2) {
		yield curPos;
		curPos[1] -= step;
	}
	while (curPos[0] < x2) {
		yield curPos;
		curPos[0] += step;
	}
	while (curPos[1] < y1) {
		yield curPos;
		curPos[1] += step;
	}
	while (curPos[0] > x1) {
		yield curPos;
		curPos[0] -= step;
	}
}

function* joinIters(...iters) {
	for (const iter of iters) {
		yield* iter;
	}
}

const time = 1e3;
const position = [4.25, 4.25];

const L = 10;
const H = 10;

const XI = 1e-3;

const boundaryTemp = 0;
const midTemp = 1;
const initialTemp = .5;

const coordStep = 3.3e-1;
const timeStep = coordStep**2 / 4;

function getIndexesByCoord(x, y) {
	return [Math.ceil(x / coordStep), Math.ceil(y / coordStep)];
}

function getCoordByIndexes(i, j) {
	return [coordStep * i, coordStep * j];
}
const positionIndexes = getIndexesByCoord(...position);

const [elementsInWidth, elementsInHeight] = getIndexesByCoord(L, H).map(i => i + 1);

const midPoint = getIndexesByCoord(L / 2, H / 2);
const [midX, midY] = midPoint;

let curState = new Array(elementsInHeight).fill(undefined).map(() => new Array(elementsInHeight).fill(initialTemp));
curState[midX][midY] = midTemp;
for (const [i, j] of circuitRange(0, 0, elementsInWidth - 1, elementsInHeight - 1)) curState[i][j] = boundaryTemp;
// console.log(curState);
let futState = new Array(elementsInHeight).fill(undefined).map(() => new Array(elementsInHeight).fill(undefined));

let domain = [];
let values = [];
for (const curTime of range(0, time, timeStep)) {
	for (const [i, j] of flatRange(1, 1, elementsInWidth - 2, elementsInHeight - 2)) {
		futState[i][j] = curState[i][j] + XI * (timeStep / coordStep**2) * ((curState[i + 1][j] - 2*curState[i][j] + curState[i + 1][j]) + (curState[i][j + 1] - 2*curState[i][j] + curState[i][j - 1]));
	}
	for (const [i, j] of circuitRange(0, 0, elementsInWidth - 1, elementsInHeight - 1)) {
		futState[i][j] = boundaryTemp;
	}
	futState[midX][midY] = midTemp;

	[curState, futState] = [futState, curState];

	domain.push(curTime);
	values.push(curState[positionIndexes[0]][positionIndexes[1]]);
}
const queryObject = {
  type: 'line',
  data: {
    labels: domain.map(val => Math.round(10*val)/10).filter((_, ind) => ind % 1000 === 0),
    datasets: [{
      label: 'curve',
      data: values.map(val => val).filter((_, ind) => ind % 1000 === 0),
      fill: false,
      borderColor: 'green',
      backgroundColor: 'green',
    }]
  }
};
const query = JSON.stringify(queryObject);
console.log(query);