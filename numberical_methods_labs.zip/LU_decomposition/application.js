const { LUDecompose, matrixCompose } = require('./index.js');

var matrix = [
	[2, 3, 7],
	[4, 5, 3],
	[11, 2, 3]
];

/* var matrix = [ [ -1 ] ]; */

const result = LUDecompose(matrix);

console.log(result);

console.log(matrixCompose(result.L, result.U), '|', matrix);
