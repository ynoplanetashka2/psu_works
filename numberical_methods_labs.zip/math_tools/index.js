function submatrix(matrix, row, column) {
	return matrix
		.map(row => row
			.filter((_, ind) => ind !== column))
		.filter((_, ind) => ind !== row);
};

function det(matrix) {
	const size = matrix.length;

	if (size === 1) {
		return matrix[0][0];
	}
	
	var sign = 1;
	var result = 0;

	for (var i = 0; i < size; i++) {
		result += sign * det(submatrix(matrix, 0, i)) * matrix[0][i];
		sign *= -1;
	}

	return result;
}

function sumVectors(...vectors) {
	if (vectors.length === 0)
		throw new Error('0 arguments passed');

	const _length = vectors[0].length;

	var result = new Array(_length).fill(0);

	vectors.forEach(vector =>
		vector.forEach((coordinate, index) =>
			result[index] += coordinate
		)
	);

	return result;
}

function scaleVector(vector, scaleFactor) {
	return vector.map(item => item * scaleFactor);
}

function inverseVector(vector) {
	return scaleVector(vector, -1);
}

function getLength(vector) {
	return Math.sqrt(vector.reduce((acc, coordinate) => acc + coordinate * coordinate, 0));
}

function applyMatrix(matrix, vector) {
	const columns = matrix
		.map((_, ind) => matrix
			.map(row => row[ind]));

	return sumVectors(...columns.map((column, index) => scaleVector(column, vector[index])));
}

function transpose(matrix) {
	var result = new Array();

	matrix[0].forEach((_, ind) => result[ind] = new Array());

	matrix
		.forEach((row, i) => row
			.forEach((el, j) => result[j][i] = el));

	return result;
}

function insertSubmatrix(matrix, submatrix, row, column) {
	for (var i = 0; i < submatrix.length; i++) {
		for (var j = 0; j < submatrix[0].length; j++) {
			matrix[row + i][column + j] = submatrix[i][j];
		}
	}
	return matrix;
}

function sumMatrix(matrix1, matrix2) {
	return matrix1
		.map((row, i) => row
			.map((item, j) => item + matrix2[i][j]));
}

function scaleMatrix(matrix, scaleFactor) {
	return matrix
		.map(row => row
			.map(item => item * scaleFactor));
}

function dotProduct(vector1, vector2) {
	return vector1.reduce((acc, i, ind) => acc + i * vector2[ind], 0);
}

function matrixCompose(matrix1, matrix2) {
	matrix2 = transpose(matrix2);
	var result = new Array();

	for (var i = 0; i < matrix1.length; i++) {
		result[i] = new Array();
		for (var j = 0; j < matrix2.length; j++) {
			result[i][j] = dotProduct(matrix1[i], matrix2[j]);
		}
	}

	return result;
}

function pow(num, power) {
	let res = 1;
	while (power--) res *= num;

	return res;
}

function div(en, den) {
	return (en - en % den) / den;
}

function* hyperRange(func, conf) {
	const _defaultConf = {
		from: 0,
		to: undefined,
		step: 1,
		arity: func.length
	};

	conf = Object.assign(_defaultConf, conf);

	const {from, to, step, arity} = conf;

	const dotCount = Math.floor((to - from) / step) + 1;
	const args = new Array(arity);

	for (var i = 0; i < dotCount ** arity; i++) {
		for (var j = 0; j < arity; j++) {
			const digit = div(i, pow(dotCount, j)) - div(i, pow(dotCount, j + 1)) * dotCount;
			args[j] = from + digit * step;
		}

		yield func(...args);
	}
}

module.exports = {
	...module.exports,
	submatrix,
	det,
	sumVectors,
	scaleVector,
	inverseVector,
	getLength,
	applyMatrix,
	scaleMatrix,
	transpose,
	insertSubmatrix,
	sumMatrix,
	scaleMatrix,
	dotProduct,
	matrixCompose,
	pow,
	div,
	hyperRange
}
