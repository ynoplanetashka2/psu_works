const { getArgMinGD } = require('../gradient_descent/index.js');

function sq(value) {
	return value * value;
}

function leastSquares(curves, points, values, startPoint = new Array(curves.length).fill(0)) {

	const argFunc = {length: curves.length};
	const coefficients = points.map(point => curves.map(curve => curve(point)));

	const generateFunc = (...coef) => (...args) => coef.reduce((sum, coef, index) => sum + coef * args[index], 0);

	const curveP = values
		.map((value, index) => (...args) => coefficients.reduce((sum, coefficients, ind) => sum + 2 * coefficients[index] * sq(generateFunc(...coefficients)(...args) - value), 0));

	const result = getArgMinGD(argFunc, curveP, 1e-2, 1e-2, startPoint, 1e6);

	console.log(generateFunc(1, 1)(2, 3));
	console.log(curveP[0](3, 5));
	return result;
}


const curves = [
	(x) => x,
	(x) => 1
];

const points = [
	0,
	1
];

const values = [
	0,
	1
]

const result = leastSquares(curves, points, values);
console.log(result);
