function getRoot(curve, leftBound, rightBound, preciseness = 1e-4) {

	const iterStep = (leftBound, rightBound) => (leftBound + rightBound) / 2;

	var middle = iterStep(leftBound, rightBound);

	while (Math.abs(curve(middle)) >= preciseness) {
		console.log(middle);
		if (curve(leftBound) * curve(middle) < 0) {
			rightBound = middle;
		}
		else if (curve(middle) * curve(rightBound) < 0) {
			leftBound = middle;
		}
		else {
			var result;
			try {
				result = getRoot(curve, leftBound, middle, preciseness);
			}
			catch (_) {
				result = getRoot(curve, middle, rightBound, preciseness);
			}
			finally {
				return result;
			}
		}

		middle = iterStep(leftBound, rightBound);
	}

	return middle;
}

// TESTS

/*
const curve = (x) => x ** 2 - 1;
console.log(getRoot(curve, -2, 1/2, 1e-6));
*/

module.exports = {
	getRoot
};
