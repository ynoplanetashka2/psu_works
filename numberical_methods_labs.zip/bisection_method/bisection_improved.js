const { pow, div, hyperRange } = require('../math_tools/index.js');

function getRoot(
	func,
	conf
) {
	const _defaultConf = {
		preciseness: 1e-3,
		intervalLength: 1e-1,
		startPoint: new Array(func.length).fill(0),
		searchRange: 1e1
	};

	conf = Object.assign(_defaultConf, conf);

	const dim = func.length;

	let { preciseness, intervalLength, startPoint, searchRange } = conf;

	const startValue = func(...startPoint);
	let currentValue = startValue;

	if (Math.max(...startValue.map(Math.abs)) < preciseness) {
		return startPoint;
	}

	var currentPoint = startPoint.slice();

	function* domain() {
		let distance = intervalLength;

		while (distance <= searchRange) {
			for (var i = 0; i < dim; i++) {
				let signum = 1;
				const genArray = (...args) => {
					args.splice(i, 0, signum * distance);
					args = args.map((item, index) => args[index] + currentPoint[index]);
					return args;
				}

				for (const point of hyperRange(genArray, {from: -distance, to: distance, step: intervalLength, arity: dim - 1})) {
					yield point;
				}

				signum = -1;

				for (const point of hyperRange(genArray, {from: -distance, to: distance, step: intervalLength, arity: dim - 1})) {
					yield point;
				}
			}
			distance += intervalLength;
		}
	}


	do {
		for (const point of domain()) {
			const pointValue = func(...point);
			if (pointValue.every((_, index) => pointValue[index] * currentValue[index] <= 0)) {
				currentPoint = point;
				break;
			}
		}

		if (currentPoint === undefined) {
			return null;
		}

		currentValue = func(...currentPoint);
		intervalLength /= 2;

	} while (Math.max(...currentValue.map(Math.abs)) >= preciseness)

	return currentPoint;
}

module.exports = {
	getRoot
}
