function sumVectors(...vectors) {
	if (vectors.length === 0)
		throw new Error('0 arguments passed');

	const _length = vectors[0].length;

	var result = new Array(_length).fill(0);

	vectors.forEach(vector =>
		vector.forEach((coordinate, index) =>
			result[index] += coordinate
		)
	);

	return result;
}

function scaleVector(vector, scaleFactor) {
	return vector.map(item => item * scaleFactor);
}

function inverseVector(vector) {
	return scaleVector(vector, -1);
}

function getLength(vector) {
	return Math.sqrt(vector.reduce((acc, coordinate) => acc + coordinate * coordinate, 0));
}

function applyMatrix(matrix, vector) {
	const columns = matrix
		.map((_, ind) => matrix
			.map(row => row[ind]));

	return sumVectors(...columns.map((column, index) => scaleVector(column, vector[index])));
}

module.exports.solveLinearSystemI = function solveLinearSystemI(matrix /* extended matrix of a system */ , preciseness) {

	var independentTerm = matrix.map(item => item[item.length - 1]);

	var matrix = matrix.map(row => row.slice(0, row.length - 1));
	var operator;

	const throwConditionError = (arg) => {
		throw new Error('invalid input. diagonal dominance condition can not be met.'  + arg);
	};

	operator = matrix.map(i => i)
		.map(row => row.map(Math.abs))
		.map(row => ({row, greatestElement: row.map(i => i).sort((fst, snd) => (snd - fst))[0]}))
		.map((item, _, arr) => (item.row.reduce((acc, i) => acc + i, 0) < 2 * item.greatestElement ? item : throwConditionError(JSON.stringify(arr))))
		.map(item => ({row: item.row, greatestElementIndex: item.row.indexOf(item.greatestElement)}))
		.map((item, index) => ({row: item.row, greatestElement: matrix[index][item.greatestElementIndex], greatestElementIndex: item.greatestElementIndex}));


	var temp = operator.map(item => item.greatestElementIndex);

	if (new Set(temp).size !== temp.length) {
		throwConditionError(JSON.stringify(operator));
	}


	[matrix, independentTerm, operator].forEach(item => item.sort((fst, snd) => {
		const fstIndex = item.indexOf(fst);
		const sndIndex = item.indexOf(snd);

		return operator[fstIndex].greatestElementIndex - operator[sndIndex].greatestElementIndex;
	}));

	independentTerm = independentTerm.map((item, index) => (1) * item / operator[index].greatestElement);
	operator = matrix
		.map((row, index) => row
			.map((item, ind) => ind === operator[index].greatestElementIndex ? 0 : (-1) * item / operator[index].greatestElement))


	operator
		.map((row, index) => row
			.map((_, ind) => operator[ind][index]))
		.forEach(column => column.reduce((sum, item) => sum + Math.abs(item), 0) < 1 ? undefined : throwConditionError(JSON.stringify(operator)));

	const iterationStep = (currentValue) => sumVectors(independentTerm, applyMatrix(operator, currentValue));

	var previousValue = independentTerm;
	var currentValue = iterationStep(previousValue);

	var iterationCount = 0;
	console.log(operator, independentTerm);
	while (getLength(sumVectors(previousValue, inverseVector(currentValue))) >= preciseness) {
		console.log(previousValue, currentValue, getLength(sumVectors(previousValue, inverseVector(currentValue))), iterationCount);
		previousValue = currentValue;
		currentValue = iterationStep(currentValue);

		iterationCount++;
	}

	return {
		iterationCount,
		solution: currentValue
	}
};



module.exports.solveLinearSystemS = function solveLinearSystemS(matrix /* extended matrix of a system */ , preciseness) {

	var independentTerm = matrix.map(item => item[item.length - 1]);

	var matrix = matrix.map(row => row.slice(0, row.length - 1));
	var operator;

	const throwConditionError = (arg) => {
		throw new Error('invalid input. diagonal dominance condition can not be met.'  + arg);
	};

	operator = matrix.map(i => i)
		.map(row => row.map(Math.abs))
		.map(row => ({row, greatestElement: row.map(i => i).sort((fst, snd) => (snd - fst))[0]}))
		.map((item, _, arr) => (item.row.reduce((acc, i) => acc + i, 0) < 2 * item.greatestElement ? item : throwConditionError(JSON.stringify(arr))))
		.map(item => ({row: item.row, greatestElementIndex: item.row.indexOf(item.greatestElement)}))
		.map((item, index) => ({row: item.row, greatestElement: matrix[index][item.greatestElementIndex], greatestElementIndex: item.greatestElementIndex}));


	var temp = operator.map(item => item.greatestElementIndex);

	if (new Set(temp).size !== temp.length) {
		throwConditionError(JSON.stringify(operator));
	}


	[matrix, independentTerm, operator].forEach(item => item.sort((fst, snd) => {
		const fstIndex = item.indexOf(fst);
		const sndIndex = item.indexOf(snd);

		return operator[fstIndex].greatestElementIndex - operator[sndIndex].greatestElementIndex;
	}));

	independentTerm = independentTerm.map((item, index) => (1) * item / operator[index].greatestElement);
	operator = matrix
		.map((row, index) => row
			.map((item, ind) => ind === operator[index].greatestElementIndex ? 0 : (-1) * item / operator[index].greatestElement))

	operator
		.map((row, index) => row
			.map((_, ind) => operator[ind][index]))
		.forEach(column => column.reduce((sum, item) => sum + Math.abs(item), 0) < 1 ? undefined : throwConditionError(JSON.stringify(operator)));

	const iterationStep = (currentValue) => {
		var result = new Array();

		for (var index = 0; index < currentValue.length; index++) {
			result[index] = result.reduce((acc, i, ind) => ind < index ? acc + i * operator[index][ind] : 0, 0) + 
				independentTerm[index] +
				currentValue.reduce((acc, i, ind) => ind >= index ? acc + i * operator[index][ind] : 0, 0);
		}

		return result;
	};


	var previousValue = independentTerm.map(i => i);
	var currentValue = iterationStep(previousValue.map(i => i), previousValue);

	var temp;

	var iterationCount = 0;
	console.log(operator, independentTerm, previousValue, currentValue);
	while (getLength(sumVectors(previousValue, inverseVector(currentValue))) >= preciseness) {

		console.log(previousValue, currentValue, getLength(sumVectors(previousValue, inverseVector(currentValue))), iterationCount);

		temp = previousValue.map(i => i);
		previousValue = currentValue.map(i => i);
		currentValue = iterationStep(currentValue, temp);


		iterationCount++;
	}

	return {
		iterationCount,
		solution: currentValue
	}
};




module.exports.applyMatrix = applyMatrix;
