const { solveLinearSystemI, solveLinearSystemS, applyMatrix } = require('./index.js');

const extendedMatrix = [
	[.9, .1, .2, 2],
	[.7, .5, 6.1, -3],
	[.1, 8.4, 2.1, -1],
];

/* const extendedMatrix = [
	[4, 0.24, -0.08, 8],
	[0.04, -0.05, 5, 20],
	[0.09, 3, -0.15, 9]
]; */

const operator = extendedMatrix.map(row => row.slice(0, row.length - 1));

var { solution, iterationCount } = solveLinearSystemI(extendedMatrix, 1e-6);

console.log(solution, iterationCount);
console.log(applyMatrix(operator, solution));


var { solution, iterationCount } = solveLinearSystemS(extendedMatrix, 1e-6);

console.log(solution, iterationCount);
console.log(applyMatrix(operator, solution));
