function integralL(curve, leftBound, rightBound, intervalLength) {
	const stepLength = intervalLength;
	const needInverse = leftBound > rightBound;

	if (needInverse) 
		[leftBound, rightBound] = [rightBound, leftBound];

	var result = 0;

	for (var i = leftBound; i < rightBound - stepLength; i += stepLength) {
		const height = curve(i);
		result += height * intervalLength;
	}

	const distance = rightBound - i;
	result += curve(i) * distance;

	return needInverse ? -result : result;
}

function integralR(curve, leftBound, rightBound, intervalLength) {
	const stepLength = intervalLength;
	const needInverse = leftBound > rightBound;

	if (needInverse) 
		[leftBound, rightBound] = [rightBound, leftBound];

	var result = 0;

	for (var i = leftBound; i < rightBound - stepLength; i += stepLength) {
		const height = curve(i + stepLength);
		result += height * intervalLength;
	}

	const distance = rightBound - i;
	result += curve(rightBound) * distance;

	return needInverse ? -result : result;
}

function integralT(curve, leftBound, rightBound, intervalLength) {
	const stepLength = intervalLength;
	const needInverse = leftBound > rightBound;

	if (needInverse) 
		[leftBound, rightBound] = [rightBound, leftBound];

	var result = 0;

	for (var i = leftBound; i < rightBound - stepLength; i += stepLength) {
		const AV = (curve(i) + curve(i + stepLength)) / 2;
		result += AV * intervalLength;
	}

	const distance = rightBound - i;
	const AV = (curve(i) + curve(rightBound)) / 2;
	result += AV * distance;

	return needInverse ? -result : result;
}

function integralS(curve, leftBound, rightBound, intervalLength) {
	const stepLength = intervalLength;
	const needInverse = leftBound > rightBound;

	if (needInverse) 
		[leftBound, rightBound] = [rightBound, leftBound];

	var result = 0;

	for (var i = leftBound; i < rightBound - stepLength; i += stepLength) {
		const middle = i + stepLength / 2;
		const area = (curve(i) + 4 * curve(middle) + curve(i + stepLength)) * stepLength / 6;
		result += area;
	}

	const distance = rightBound - i;
	const middle = i + distance / 2;
	const area = (curve(i) + 4 * curve(middle) + curve(rightBound)) * distance / 6;
	result += area;

	return needInverse ? -result : result;
}

module.exports = {
	integralL,
	integralR,
	integralT,
	integralS
};

