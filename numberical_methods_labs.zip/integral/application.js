const { integralL, integralR, integralT, integralS } = require('./index.js');

const sq = (x) => x * x;

var curve = (x) => Math.sqrt(.8 * sq(x) + 2) / (1.6 + Math.sqrt(1.5 * x + .6));

console.log(
	integralL(curve, 1, 2.2, 1e-6),
	integralR(curve, 1, 2.2, 1e-6),
	integralT(curve, 1, 2.2, 1e-6),
	integralS(curve, 1, 2.2, 1e-6)
);

var curve = (x) => Math.sin(x + .7) / (1.4 + Math.cos(.6 * x + .4));

console.log(
	integralL(curve, .6, 1, 1e-6),
	integralR(curve, .6, 1, 1e-6),
	integralT(curve, .6, 1, 1e-6),
	integralS(curve, .6, 1, 1e-6)
);

var curve = (x) => 1 / Math.sqrt(12 * sq(x) + .5);

console.log(
	integralL(curve, .6, 1.4, 1e-6),
	integralR(curve, .6, 1.4, 1e-6),
	integralT(curve, .6, 1.4, 1e-6),
	integralS(curve, .6, 1.4, 1e-6)
);

var curve = (x) => Math.log10(1 + sq(x)) / (2 * x - 1);

console.log(
	integralL(curve, 1.2, 1, 1e-2),
	integralR(curve, 1.2, 1, 1e-2),
	integralT(curve, 1.2, 1, 1e-2),
	integralS(curve, 1.2, 1, 1e-2)
);