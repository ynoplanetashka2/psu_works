const { inverseVector, sumVectors } = require('../math_tools/index.js');
const { getArgMinGD } = require('../gradient_descent/index.js');

function getArgMinCD(
	curve,
	curveP,
	initialValue = new Array(curve.length).fill(0),
	preciseness = 1e-3
) {

	const arity = initialValue.length;
	var currentValue = initialValue;
	var maxItem;

	var iterationCount = 0;
	const iterStep = (currentValue) => {
		// console.log(iterationCount++);
		for (var i = 0; i < arity; i++) {
			const partialCurve = (x) => {
				const variables = currentValue.slice(0, i).concat([x], currentValue.slice(i + 1));
				return curve(...variables);
			};

			const partialCurveP = (x) => {
				const variables = currentValue.slice(0, i).concat([x], currentValue.slice(i + 1));
				return curveP[i](...variables);
			};

			const [argMin] = getArgMinGD(partialCurve, [partialCurveP], 1e-3, preciseness, [currentValue[i]], 1e6);

			currentValue[i] = argMin;
		}

		return currentValue;
	}

	do {

		const previousValue = currentValue.map(i => i);
		currentValue = iterStep(currentValue);

		const delta = sumVectors(
			inverseVector(previousValue),
			currentValue
		);

		maxItem = delta.map(Math.abs).sort((a, b) => b - a)[0];

	} while (maxItem >= preciseness)
		
	return currentValue;
}

module.exports = {
	getArgMinCD
}
