const { getArgMinCD } = require('./index.js');
const { getArgMinGD } = require('../gradient_descent/index.js');

const curve = (x, y) => 2 * x**2 + y**2 - x * y;

const curveP = [
	(x, y) => 4 * x - y,
	(x, y) => 2 * y - x
];

const initialValue = [2, 1];

const result = getArgMinCD(curve, curveP, initialValue, 1e-6);

console.log(result);
console.log(getArgMinGD(curve, curveP, 1e-3, 1e-6, initialValue, 1e6));
