module.exports.transformCurveX = function transformCurveX(curve, coefficient) {
	return (x, y) => (x - curve(x, y) / coefficient);
}


module.exports.transformCurveY = function transformCurveY(curve, coefficient) {
	return (x, y) => (y - curve(x, y) / coefficient);
}


module.exports.getFixedPointOfSystem = function getFixedPointOfSystem(curve1, curve2, xLowerBound, xUpperBound, yLowerBound, yUpperBound, preciseness) {
	var xPrevious = xLowerBound,
	    yPrevious = yLowerBound,
	    xCurrent = curve1(xPrevious, yPrevious),
	    yCurrent = curve2(xPrevious, yPrevious);

	var xDif = Math.abs(xCurrent - xPrevious),
	    yDif = Math.abs(yCurrent - yPrevious);

	var xTemp,
	    yTemp;

	var iterCount = 0;

	while (Math.max(xDif, yDif) >= preciseness) {

		xTemp = xCurrent;
		yTemp = yCurrent;
		console.log(`x: ${xTemp}, y: ${yTemp}, iteration: ${iterCount}.`);

		xCurrent = curve1(xTemp, yTemp);
		yCurrent = curve2(xTemp, yTemp);

		xPrevious = xTemp;
		yPrevious = yTemp;

		xDif = Math.abs(xCurrent - xPrevious);
		yDif = Math.abs(yCurrent - yPrevious);

		iterCount++;
	}

	return {
		x: xCurrent,
		y: yCurrent
	};
}


