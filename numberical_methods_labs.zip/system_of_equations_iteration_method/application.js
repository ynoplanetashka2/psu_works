const {transformCurveX, transformCurveY, getFixedPointOfSystem} = require('./index.js');

const aCurve1 = (x, y) => Math.sin(x + .5) - y - 1.2;
const aCurve2 = (x, y) => Math.cos(y - 2) + x;

const aTransformedCurve1 = transformCurveX(aCurve1, 20);
const aTransformedCurve2 = transformCurveY(aCurve2, 20);

const aFixedPoint = getFixedPointOfSystem(
		aTransformedCurve1,
		aTransformedCurve2,
		-3,
		0,
		-1.5,
		1.5,
		1e-6
	);

console.log(aFixedPoint);
